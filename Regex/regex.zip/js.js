/* pour l’activité :

 Il faut que tu me crées une regex qui match tout type d’url, sachant qu’une url c’est :
 * le protocole
 * le user
 * le mot de passe
 * le nom de domaine complet (obligatoire)
 * le port
 * le chemin */
// initialisation du programme

var url = prompt("entrez votre URL:");
/* penser a mettre une fonction qui exclut
 les espaces pour gérer le copier coller utiliser en méthode trim ()*/

if(/^(?:https|ftp|http|steam|mailto|wais|gopher|telnet):(?:\/\/)(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z0-9]+-?)*[a-z0-9]+)(?:\.(?:[a-z0-9]+-?)*[a-z0-9]+)*(?:\.(?:[a-z]{2,9})))(?::\d{2,5})?(?:\/[^\s]*)/i.test(url)){
    alert("cette url "+ url+" est valide");
}else{
    alert("cette Url"+ url+"n'est pas valide");
}
